import React from 'react'

export default props => (
    <section className='content'>{props.children}</section>
)