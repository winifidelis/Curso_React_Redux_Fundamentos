import React from 'react'

export default props => (
    <footer className='main-footer'> 
        <strong> 
            Copyright &copy; 2017
            <a href='http://cod3r.com.br' target='_blank'> Cod3r</a>.
        </strong>
    </footer>
)