import React from 'react'

export default props => (
    <div className='row'>{props.children}</div>
)