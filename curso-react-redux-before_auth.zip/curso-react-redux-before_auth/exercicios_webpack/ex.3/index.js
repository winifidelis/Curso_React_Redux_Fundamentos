/*
 * Quando o arquivo não é referenciado
 * ele não será considerado para a geração
 * do arquivo bundle.js
 */