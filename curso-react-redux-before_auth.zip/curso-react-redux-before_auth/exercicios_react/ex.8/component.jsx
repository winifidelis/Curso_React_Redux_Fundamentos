import React from 'react'

export default props => (
    <h1>Primeiro Componente!</h1>
)

export const Segundo = props => (
    <h1>Segundo Componente!</h1>
)

// export { Primeiro, Segundo }