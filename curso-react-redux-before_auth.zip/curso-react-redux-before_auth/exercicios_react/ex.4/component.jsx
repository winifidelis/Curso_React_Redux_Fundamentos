import React from 'react'

export default () => (
    <h1>Primeiro Componente!</h1>
)