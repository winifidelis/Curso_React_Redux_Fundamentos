# Changelog

# [1.2.1]

### Updated
- Packages updated

### Fixed
- Sign up name type of input
- Dot component size prop
- Performance errors

# [1.2.0]

### Updated
- Packages update
- Link to Full version

### Fixed
- User login state improvements

## [1.1.0]

### New Feactures

- React v16.8.6
- React Router v5
- new React Hooks
- Material UI v4.3

Bug fixes

## [1.0.0]

Initial version of the project
