import image1 from "./images/image1.jpg";
import image2 from "./images/image2.jpg";
import image3 from "./images/image3.jpg";
import image4 from "./images/image4.jpg";
import image5 from "./images/image5.jpg";
import image6 from "./images/image6.jpg";
import image7 from "./images/image7.jpg";
import image8 from "./images/image8.jpg";
import image9 from "./images/image9.jpg";
import image10 from "./images/image10.jpg";

export default [
  {
    profilePicUrl: image1,
    name: "Markus"
  },
  {
    profilePicUrl: image2,
    name: "David"
  },
  {
    profilePicUrl: image3,
    name: "Arold"
  },
  {
    profilePicUrl: image4,
    name: "Joanic"
  },
  {
    profilePicUrl: image5,
    name: "Sophia"
  },
  {
    profilePicUrl: image6,
    name: "Aaron"
  },
  {
    profilePicUrl: image7,
    name: "Steven"
  },
  {
    profilePicUrl: image8,
    name: "Felix"
  },
  {
    profilePicUrl: image9,
    name: "Vivien"
  },
  {
    profilePicUrl: image10,
    name: "Leonie"
  }
];
