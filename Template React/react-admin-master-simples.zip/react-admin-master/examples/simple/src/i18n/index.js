import enMessages from './en';
import frMessages from './fr';

export const en = enMessages;
export const fr = frMessages;
