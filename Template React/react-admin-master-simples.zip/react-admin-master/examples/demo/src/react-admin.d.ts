declare module 'react-admin';
