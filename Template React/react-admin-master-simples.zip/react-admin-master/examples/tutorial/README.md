# React-admin tutorial

This is the application built while following the [tutorial](https://marmelab.com/react-admin/Tutorial.html).

## How to run

After having cloned the react-admin repository, run the following commands:

```sh
make install

make run-tutorial
```
