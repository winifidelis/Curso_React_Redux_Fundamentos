import useLoading from './useLoading';
import useUpdateLoading from './useUpdateLoading';

export { useLoading, useUpdateLoading };
