export const REDUX_FORM_NAME = 'record-form';
